import Welcome from './components/Welcome'

import './App.css'

const App = () => <Welcome />

export default App
